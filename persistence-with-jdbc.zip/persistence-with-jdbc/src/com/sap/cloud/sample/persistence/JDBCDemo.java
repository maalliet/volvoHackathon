package com.sap.cloud.sample.persistence;


import java.io.IOException;
import java.sql.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
public class JDBCDemo {
	
   public JDBCDemo(HttpServletResponse response) throws ServletException, IOException {
	   
	   try {
		   InitialContext ctx = new InitialContext();
		   DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");
		   String STMT_SELECT_ALL = "SELECT * FROM sap.hana.uis.db::_UIS_PERMISSIONS";
		   Connection conn = ds.getConnection();
		   PreparedStatement pstmt = conn.prepareStatement(STMT_SELECT_ALL);
	        ResultSet rs = pstmt.executeQuery();
	        response.getWriter().println(rs.toString());
	} catch (NamingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		response.getWriter().println("NamingException   ");
	} catch(SQLException e){
		response.getWriter().println(e.getMessage()+"    ");
	} 
	   
	   
      Connection connection = null;
      try {                  
         connection = DriverManager.getConnection (
            "jdbc:sap://p1942443965trial.hanatrial.ondemand.com:30715/?autocommit=false","SYSTEM","Deloitte-1");                  
      } catch (SQLException e) {
			response.getWriter().println("Connection Failed. User/Passwd Error?");
         return;
      }
      
      if (connection != null) {
         try {
        	 response.getWriter().println("Connection to HANA successful!");
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("Select 'hello world' from dummy");
            resultSet.next();
            String hello = resultSet.getString(1);
            response.getWriter().println(hello);
       } catch (SQLException e) {
    	   response.getWriter().println("Query failed!");
       }
     }
   }
}